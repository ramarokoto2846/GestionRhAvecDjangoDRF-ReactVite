// src/App.jsx
import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Auth from "./pages/Auth";
import Home from "./pages/Home";
import PrivateRoute from "./components/PrivateRoute";

import Employes from "./pages/Employes";
import Departements from "./pages/Departements";
import Pointages from "./pages/Pointages";
import Absences from "./pages/Absences";
import Evenements from "./pages/Evenements";
import Conges from "./pages/Conges";

// Tableau de config des routes privées
const privateRoutes = [
  { path: "/home", element: <Home /> },
  { path: "/employes", element: <Employes /> },
  { path: "/departements", element: <Departements /> },
  { path: "/pointages", element: <Pointages /> },
  { path: "/conges", element: <Conges /> },
  { path: "/absences", element: <Absences /> },
  { path: "/evenements", element: <Evenements /> },
];

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(
    !!localStorage.getItem("access_token")
  );

  return (
    <Routes>
      {/* Page publique */}
      <Route
        path="/"
        element={<Auth setIsAuthenticated={setIsAuthenticated} />}
      />

      {/* Routes privées générées automatiquement */}
      {privateRoutes.map(({ path, element }) => (
        <Route
          key={path}
          path={path}
          element={<PrivateRoute>{element}</PrivateRoute>}
        />
      ))}
    </Routes>
  );
}

export default App;
