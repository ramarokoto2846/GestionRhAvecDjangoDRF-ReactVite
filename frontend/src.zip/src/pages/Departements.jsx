import React, { useState, useEffect } from "react";
import {
  AppBar,
  Toolbar,
  Box,
  Typography,
  IconButton,
  Badge,
  Avatar,
  Button,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  InputAdornment,
  Snackbar,
  Alert,
  Fab,
  Card,
  CardContent,
  CircularProgress,
} from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import { Link, useLocation } from "react-router-dom";
import {
  Notifications as NotificationsIcon,
  Settings as SettingsIcon,
  Logout as LogoutIcon,
  Menu as MenuIcon,
  Apartment as ApartmentIcon,
  People as PeopleIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Close as CloseIcon,
  Save as SaveIcon,
  Home as HomeIcon,
  AccessTime as AccessTimeIcon,
  BeachAccess as BeachAccessIcon,
  Block as BlockIcon,
  EventAvailable as EventAvailableIcon
} from "@mui/icons-material";

// Import des fonctions API
import { getDepartements, createDepartement, updateDepartement, deleteDepartement } from "../services/api";

const drawerWidth = 240;

const Departements = () => {
  const theme = useTheme();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingDepartement, setEditingDepartement] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  // Formulaire avec id_departement
  const [formData, setFormData] = useState({
    id_departement: "",
    nom: "",
    responsable: "",
    description: "",
    localisation: "",
    nbr_employe: 0,
  });

  // Données récupérées depuis l'API
  const [departements, setDepartements] = useState([]);

  const user = { nom: "Admin", email: "admin@example.com" };
  const notificationsCount = 3;

  const menuItems = [
    { text: "Accueil", path: "/Home", icon: <HomeIcon /> },
    { text: "Employés", path: "/employes", icon: <PeopleIcon /> },
    { text: "Départements", path: "/departements", icon: <ApartmentIcon /> },
    { text: "Pointages", path: "/pointages", icon: <AccessTimeIcon /> },
    { text: "Congés", path: "/conges", icon: <BeachAccessIcon /> },
    { text: "Absences", path: "/absences", icon: <BlockIcon /> },
    { text: "Événements", path: "/evenements", icon: <EventAvailableIcon /> }
  ];

  // Charger les données depuis l'API
  useEffect(() => {
    fetchDepartements();
  }, []);

  const fetchDepartements = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getDepartements();
      console.log("Données reçues de l'API :", data);
      const departementsArray = Array.isArray(data) ? data : (Array.isArray(data.data) ? data.data : []);
      if (departementsArray.length === 0) {
        console.warn("Aucun département retourné par l'API.");
      }
      setDepartements(departementsArray);
      setLoading(false);
    } catch (error) {
      console.error("Erreur détaillée lors du chargement des départements:", error);
      const errorMessage = error.response
        ? `Erreur ${error.response.status}: ${error.response.data?.message || error.message}`
        : `Erreur réseau: ${error.message}`;
      setError(errorMessage);
      showSnackbar(errorMessage, "error");
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("access_token");
    window.location.href = "/";
  };

  const handleOpenDialog = (departement = null) => {
    if (departement) {
      setEditingDepartement(departement);
      setFormData({
        id_departement: departement.id_departement || "",
        nom: departement.nom || "",
        responsable: departement.responsable || "",
        description: departement.description || "",
        localisation: departement.localisation || "",
        nbr_employe: departement.nbr_employe || 0,
      });
    } else {
      setEditingDepartement(null);
      setFormData({
        id_departement: "",
        nom: "",
        responsable: "",
        description: "",
        localisation: "",
        nbr_employe: 0,
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingDepartement(null);
    setFormData({
      id_departement: "",
      nom: "",
      responsable: "",
      description: "",
      localisation: "",
      nbr_employe: 0,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.id_departement.trim() && !editingDepartement) {
      showSnackbar("L'ID du département est requis", "error");
      return;
    }
    if (!formData.nom.trim() || !formData.responsable.trim()) {
      showSnackbar("Le nom et le responsable sont requis", "error");
      return;
    }
    try {
      if (editingDepartement) {
        await updateDepartement(editingDepartement.id_departement, formData);
        showSnackbar("Département modifié avec succès", "success");
      } else {
        await createDepartement(formData);
        showSnackbar("Département créé avec succès", "success");
      }
      fetchDepartements();
      handleCloseDialog();
    } catch (error) {
      console.error("Erreur lors de la sauvegarde:", error);
      const errorMessage = error.response
        ? `Erreur ${error.response.status}: ${error.response.data?.message || error.message}`
        : `Erreur: ${error.message}`;
      showSnackbar(errorMessage, "error");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer ce département ?")) {
      try {
        await deleteDepartement(id);
        showSnackbar("Département supprimé avec succès", "success");
        fetchDepartements();
      } catch (error) {
        console.error("Erreur lors de la suppression:", error);
        const errorMessage = error.response
          ? `Erreur ${error.response.status}: ${error.response.data?.message || error.message}`
          : `Erreur: ${error.message}`;
        showSnackbar(errorMessage, "error");
      }
    }
  };

  const showSnackbar = (message, severity = "success") => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const handleChangePage = (event, newPage) => setPage(newPage);
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const filteredData = departements.filter(
    (dept) =>
      (dept.id_departement || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (dept.nom || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (dept.responsable || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (dept.localisation || "").toLowerCase().includes(searchTerm.toLowerCase())
  );

  const paginatedData = filteredData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  if (error) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <Typography color="error">{error}</Typography>
        <Button onClick={fetchDepartements} sx={{ ml: 2 }} variant="contained" color="primary">
          Réessayer
        </Button>
      </Box>
    );
  }

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ display: "flex" }}>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          bgcolor: "white",
          color: "text.primary",
          borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
          zIndex: theme.zIndex.drawer + 1,
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            onClick={() => setOpen(!open)}
            sx={{ mr: 2, display: { md: "none" } }}
          >
            <MenuIcon />
          </IconButton>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: 2,
                bgcolor: "primary.main",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mr: 2,
                color: "white",
                fontWeight: "bold",
                fontSize: 18,
              }}
            >
              RH
            </Box>
            <Typography variant="h6" sx={{ fontWeight: "bold", color: "#1976d2" }}>
              RHManager Pro
            </Typography>
          </Box>
          <Box sx={{ flexGrow: 1 }} />
          <IconButton
            color="inherit"
            sx={{
              mr: 1,
              bgcolor: alpha(theme.palette.primary.main, 0.1),
              "&:hover": { bgcolor: alpha(theme.palette.primary.main, 0.2) },
            }}
          >
            <Badge badgeContent={notificationsCount} color="error">
              <NotificationsIcon />
            </Badge>
          </IconButton>
          <IconButton
            sx={{
              mr: 1,
              bgcolor: alpha(theme.palette.grey[500], 0.1),
              "&:hover": { bgcolor: alpha(theme.palette.grey[500], 0.2) },
            }}
          >
            <SettingsIcon />
          </IconButton>
          <Box sx={{ display: "flex", alignItems: "center", mr: 2 }}>
            <Avatar
              sx={{
                bgcolor: "primary.main",
                width: 40,
                height: 40,
                mr: 1.5,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              {user.nom.charAt(0).toUpperCase()}
            </Avatar>
            <Box sx={{ display: { xs: "none", sm: "block" } }}>
              <Typography variant="body2" sx={{ fontWeight: "medium" }}>
                {user.nom}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Administrateur
              </Typography>
            </Box>
          </Box>
          <Button
            color="error"
            onClick={handleLogout}
            startIcon={<LogoutIcon />}
            variant="outlined"
            size="small"
            sx={{ borderRadius: 2, textTransform: "none", fontWeight: "medium" }}
          >
            Déconnexion
          </Button>
        </Toolbar>
      </AppBar>

      {/* Sidebar */}
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: "border-box" },
          display: { xs: "none", md: "block" },
        }}
        open
      >
        <Toolbar />
        <Divider />
        <List>
          {menuItems.map((item) => (
            <ListItem key={item.text} disablePadding>
              <ListItemButton
                component={Link}
                to={item.path}
                selected={location.pathname === item.path}
              >
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>

      <Drawer
        anchor="left"
        open={open}
        onClose={() => setOpen(false)}
        sx={{ display: { md: "none" } }}
      >
        <Box sx={{ width: drawerWidth }} role="presentation">
          <List>
            {menuItems.map((item) => (
              <ListItem key={item.text} disablePadding>
                <ListItemButton
                  component={Link}
                  to={item.path}
                  onClick={() => setOpen(false)}
                  selected={location.pathname === item.path}
                >
                  <ListItemIcon>{item.icon}</ListItemIcon>
                  <ListItemText primary={item.text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Contenu */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          bgcolor: "#f8fafc",
          minHeight: "100vh",
          p: 3,
          mt: 8,
          ml: { md: `${drawerWidth}px` },
        }}
      >
        {/* Header et bouton ajout */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
          <Box>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: "bold", color: "text.primary" }}>
              Gestion des Départements
            </Typography>
            <Typography variant="body1" color="text.secondary">
              Gérez les départements de votre entreprise
            </Typography>
          </Box>
          <Fab
            color="primary"
            aria-label="add"
            onClick={() => handleOpenDialog()}
            sx={{ borderRadius: 2, px: 3, textTransform: "none", fontWeight: "bold" }}
          >
            <AddIcon sx={{ mr: 2 }} />
            Nouveau Département
          </Fab>
        </Box>

        {/* Stats */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ borderRadius: 3, boxShadow: 2 }}>
              <CardContent>
                <Typography color="text.secondary" gutterBottom>
                  Total Départements
                </Typography>
                <Typography
                  variant="h4"
                  component="div"
                  sx={{ fontWeight: "bold", color: "primary.main" }}
                >
                  {departements.length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ borderRadius: 3, boxShadow: 2 }}>
              <CardContent>
                <Typography color="text.secondary" gutterBottom>
                  Total Employés
                </Typography>
                <Typography
                  variant="h4"
                  component="div"
                  sx={{ fontWeight: "bold", color: "secondary.main" }}
                >
                  {departements.reduce((sum, dept) => sum + (dept.nbr_employe || 0), 0)}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Recherche */}
        <Paper sx={{ p: 2, mb: 3, borderRadius: 3 }}>
          <TextField
            fullWidth
            placeholder="Rechercher un département..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
              endAdornment: searchTerm && (
                <InputAdornment position="end">
                  <IconButton onClick={() => setSearchTerm("")} size="small">
                    <CloseIcon />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Paper>

        {/* Tableau */}
        <Paper sx={{ width: "100%", overflow: "hidden", borderRadius: 3 }}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: "bold" }}>ID Département</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>Nom</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>Responsable</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>Localisation</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>Employés</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedData.length > 0 ? (
                  paginatedData.map((row) => (
                    <TableRow key={row.id_departement} hover>
                      <TableCell>
                        <Chip label={row.id_departement || "N/A"} color="primary" variant="outlined" />
                      </TableCell>
                      <TableCell>
                        <Typography variant="subtitle2" sx={{ fontWeight: "medium" }}>
                          {row.nom || "N/A"}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {row.description || "Aucune description"}
                        </Typography>
                      </TableCell>
                      <TableCell>{row.responsable || "Non défini"}</TableCell>
                      <TableCell>{row.localisation || "Non défini"}</TableCell>
                      <TableCell>
                        <Chip
                          label={row.nbr_employe || 0}
                          color={row.nbr_employe > 20 ? "success" : "default"}
                          variant="filled"
                        />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: "flex", gap: 1 }}>
                          <IconButton
                            size="small"
                            color="primary"
                            onClick={() => handleOpenDialog(row)}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            size="small"
                            color="error"
                            onClick={() => handleDelete(row.id_departement)}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} align="center">
                      {searchTerm 
                        ? "Aucun résultat trouvé pour votre recherche" 
                        : (departements.length === 0 
                          ? "Aucun département disponible. Ajoutez un nouveau département pour commencer." 
                          : "Aucun département enregistré"
                          )
                      }
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          {filteredData.length > 0 && (
            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={filteredData.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              labelRowsPerPage="Lignes par page :"
            />
          )}
        </Paper>

        {/* Dialog */}
        <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
          <DialogTitle>{editingDepartement ? "Modifier le département" : "Nouveau département"}</DialogTitle>
          <form onSubmit={handleSubmit}>
            <DialogContent>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="ID du département"
                    value={formData.id_departement}
                    onChange={(e) => setFormData({ ...formData, id_departement: e.target.value })}
                    required
                    disabled={editingDepartement !== null}
                    error={!formData.id_departement.trim() && !editingDepartement}
                    helperText={
                      !formData.id_departement.trim() && !editingDepartement
                        ? "L'ID du département est requis"
                        : "Exemple : DEP001"
                    }
                    inputProps={{ maxLength: 10 }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Nom du département"
                    value={formData.nom}
                    onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                    required
                    error={!formData.nom.trim()}
                    helperText={!formData.nom.trim() ? "Le nom est requis" : ""}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Responsable"
                    value={formData.responsable}
                    onChange={(e) => setFormData({ ...formData, responsable: e.target.value })}
                    required
                    error={!formData.responsable.trim()}
                    helperText={!formData.responsable.trim() ? "Le responsable est requis" : ""}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Description"
                    value={formData.description || ""}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    multiline
                    rows={3}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Localisation"
                    value={formData.localisation || ""}
                    onChange={(e) => setFormData({ ...formData, localisation: e.target.value })}
                  />
                </Grid>
                
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDialog} color="inherit">
                Annuler
              </Button>
              <Button
                type="submit"
                color="primary"
                variant="contained"
                startIcon={<SaveIcon />}
                disabled={loading}
              >
                {editingDepartement ? "Mettre à jour" : "Enregistrer"}
              </Button>
            </DialogActions>
          </form>
        </Dialog>

        {/* Snackbar */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={handleCloseSnackbar}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={handleCloseSnackbar}
            severity={snackbar.severity}
            sx={{ width: "100%" }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </Box>
  );
};

export default Departements;