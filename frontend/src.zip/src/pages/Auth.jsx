import React, { useState } from "react";
import { 
  Tabs, 
  Tab, 
  Box, 
  TextField, 
  Button, 
  Typography, 
  Paper, 
  Alert,
  Fade,
  InputAdornment,
  IconButton,
  Divider
} from "@mui/material";
import { 
  Visibility, 
  VisibilityOff, 
  Person, 
  Email, 
  Lock,
  CorporateFare
} from "@mui/icons-material";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";

const Auth = ({ setIsAuthenticated }) => {
  const [tab, setTab] = useState(0);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [nom, setNom] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();

  const handleTabChange = (event, newValue) => {
    setTab(newValue);
    setEmail("");
    setPassword("");
    setConfirmPassword("");
    setNom("");
    setError("");
  };

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleClickShowConfirmPassword = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  // Inscription avec l'API Django
  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    
    if (password !== confirmPassword) {
      setError("Les mots de passe ne correspondent pas");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('http://localhost:8000/api/register/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
          password: password,
          nom: nom
        })
      });

      if (response.ok) {
        const data = await response.json();
        Swal.fire({
          title: "Succès",
          text: "Compte créé avec succès !",
          icon: "success",
          background: "#1a237e",
          color: "#fff",
          confirmButtonColor: "#42a5f5"
        });
        setTab(1); // Passer à l'onglet de connexion
      } else {
        const errorData = await response.json();
        const errorMessage = errorData.detail || 
                            errorData.email?.[0] || 
                            errorData.password?.[0] || 
                            "Erreur lors de la création du compte";
        setError(errorMessage);
      }
    } catch (error) {
      setError("Impossible de se connecter au serveur");
    } finally {
      setLoading(false);
    }
  };

  // Connexion avec l'API Django
  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await fetch('http://localhost:8000/api/token/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
          password: password
        })
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('access_token', data.access);
        localStorage.setItem('refresh_token', data.refresh);
        localStorage.setItem('user_email', email);
        
        // Récupérer les informations utilisateur
        try {
          const userResponse = await fetch('http://localhost:8000/api/users/me/', {
            headers: {
              'Authorization': `Bearer ${data.access}`
            }
          });
          
          if (userResponse.ok) {
            const userData = await userResponse.json();
            localStorage.setItem('user_name', userData.nom || userData.email);
          }
        } catch (userError) {
          console.error("Erreur lors de la récupération des infos utilisateur:", userError);
        }
        
        Swal.fire({
          title: "Succès",
          text: "Connexion réussie !",
          icon: "success",
          background: "#1a237e",
          color: "#fff",
          confirmButtonColor: "#42a5f5"
        });
        setIsAuthenticated(true);
        navigate("/home");
      } else {
        const errorData = await response.json();
        const errorMessage = errorData.detail || "Email ou mot de passe incorrect";
        setError(errorMessage);
      }
    } catch (error) {
      setError("Impossible de se connecter au serveur");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box 
      sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #1a237e 0%, #283593 30%, #3949ab 70%, #42a5f5 100%)',
        p: 2,
        position: 'relative',
        overflow: 'hidden',
        '&::before': {
          content: '""',
          position: 'absolute',
          width: '100%',
          height: '100%',
          backgroundImage: 'radial-gradient(circle at 20% 30%, rgba(255, 255, 255, 0.1) 0%, transparent 40%)',
          pointerEvents: 'none'
        }
      }}
    >
      {/* Formes décoratives */}
      <Box
        sx={{
          position: 'absolute',
          top: '-10%',
          right: '-5%',
          width: 300,
          height: 300,
          borderRadius: '50%',
          background: 'linear-gradient(135deg, rgba(66, 165, 245, 0.2) 0%, rgba(25, 118, 210, 0.2) 100%)',
          filter: 'blur(20px)'
        }}
      />
      <Box
        sx={{
          position: 'absolute',
          bottom: '-10%',
          left: '-5%',
          width: 300,
          height: 300,
          borderRadius: '50%',
          background: 'linear-gradient(135deg, rgba(57, 73, 171, 0.2) 0%, rgba(40, 53, 147, 0.2) 100%)',
          filter: 'blur(20px)'
        }}
      />
      
      <Fade in timeout={800}>
        <Paper 
          elevation={24} 
          sx={{ 
            maxWidth: 500, 
            width: '100%', 
            p: 4, 
            borderRadius: 4,
            background: 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(10px)',
            boxShadow: '0 15px 35px rgba(0, 0, 0, 0.2)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            position: 'relative',
            zIndex: 1,
            overflow: 'hidden',
            '&::before': {
              content: '""',
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: 6,
              background: 'linear-gradient(90deg, #42a5f5, #1a237e)'
            }
          }}
        >
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <CorporateFare 
              sx={{ 
                fontSize: 50, 
                color: 'primary.main',
                background: 'linear-gradient(135deg, #1a237e, #42a5f5)',
                backgroundClip: 'text',
                textFillColor: 'transparent',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                mb: 1
              }} 
            />
            <Typography 
              variant="h3" 
              component="h1" 
              gutterBottom 
              color="primary"
              sx={{ 
                fontWeight: 'bold',
                background: 'linear-gradient(135deg, #1a237e, #42a5f5)',
                backgroundClip: 'text',
                textFillColor: 'transparent',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              RHManager Pro
            </Typography>
            <Typography 
              variant="body2" 
              color="text.secondary"
              sx={{ mt: 1 }}
            >
              Gestion des ressources humaines simplifiée
            </Typography>
          </Box>
          
          <Tabs 
            value={tab} 
            onChange={handleTabChange} 
            centered 
            sx={{ 
              mb: 3,
              '& .MuiTab-root': {
                fontWeight: 600,
                fontSize: '1rem',
                textTransform: 'none',
                minWidth: 120,
                color: 'text.secondary',
                '&.Mui-selected': {
                  color: 'primary.main',
                }
              },
              '& .MuiTabs-indicator': {
                height: 3,
                borderRadius: 2,
                background: 'linear-gradient(90deg, #42a5f5, #1a237e)'
              }
            }}
          >
            <Tab label="Inscription" />
            <Tab label="Connexion" />
          </Tabs>

          {error && (
            <Alert 
              severity="error" 
              sx={{ 
                mb: 3, 
                borderRadius: 2,
                alignItems: 'center',
                '& .MuiAlert-message': {
                  padding: '4px 0'
                }
              }}
            >
              {error}
            </Alert>
          )}

          {tab === 0 && (
            <Fade in timeout={500}>
              <Box>
                <form onSubmit={handleRegister}>
                  <TextField 
                    label="Nom complet" 
                    fullWidth 
                    margin="normal" 
                    value={nom} 
                    onChange={e => setNom(e.target.value)}
                    required
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Person color="primary" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        transition: 'all 0.3s ease',
                        '&:hover fieldset': {
                          borderColor: 'primary.main',
                        },
                        '&.Mui-focused fieldset': {
                          borderWidth: 2,
                          boxShadow: '0 0 0 4px rgba(25, 118, 210, 0.1)'
                        }
                      }
                    }}
                  />
                  <TextField 
                    label="Email" 
                    type="email"
                    fullWidth 
                    margin="normal" 
                    value={email} 
                    onChange={e => setEmail(e.target.value)}
                    required
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Email color="primary" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        transition: 'all 0.3s ease',
                        '&:hover fieldset': {
                          borderColor: 'primary.main',
                        },
                        '&.Mui-focused fieldset': {
                          borderWidth: 2,
                          boxShadow: '0 0 0 4px rgba(25, 118, 210, 0.1)'
                        }
                      }
                    }}
                  />
                  <TextField 
                    label="Mot de passe" 
                    type={showPassword ? "text" : "password"}
                    fullWidth 
                    margin="normal" 
                    value={password} 
                    onChange={e => setPassword(e.target.value)}
                    required
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Lock color="primary" />
                        </InputAdornment>
                      ),
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            aria-label="toggle password visibility"
                            onClick={handleClickShowPassword}
                            edge="end"
                            size="small"
                          >
                            {showPassword ? <VisibilityOff /> : <Visibility />}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        transition: 'all 0.3s ease',
                        '&:hover fieldset': {
                          borderColor: 'primary.main',
                        },
                        '&.Mui-focused fieldset': {
                          borderWidth: 2,
                          boxShadow: '0 0 0 4px rgba(25, 118, 210, 0.1)'
                        }
                      }
                    }}
                  />
                  <TextField 
                    label="Confirmer le mot de passe" 
                    type={showConfirmPassword ? "text" : "password"}
                    fullWidth 
                    margin="normal" 
                    value={confirmPassword} 
                    onChange={e => setConfirmPassword(e.target.value)}
                    required
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Lock color="primary" />
                        </InputAdornment>
                      ),
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            aria-label="toggle confirm password visibility"
                            onClick={handleClickShowConfirmPassword}
                            edge="end"
                            size="small"
                          >
                            {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        transition: 'all 0.3s ease',
                        '&:hover fieldset': {
                          borderColor: 'primary.main',
                        },
                        '&.Mui-focused fieldset': {
                          borderWidth: 2,
                          boxShadow: '0 0 0 4px rgba(25, 118, 210, 0.1)'
                        }
                      }
                    }}
                  />
                  <Button 
                    type="submit" 
                    variant="contained" 
                    color="primary" 
                    fullWidth 
                    sx={{ 
                      mt: 3, 
                      py: 1.5,
                      borderRadius: 2,
                      fontSize: '1rem',
                      fontWeight: 600,
                      textTransform: 'none',
                      background: 'linear-gradient(135deg, #1a237e, #42a5f5)',
                      boxShadow: '0 4px 12px rgba(25, 118, 210, 0.3)',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 6px 16px rgba(25, 118, 210, 0.4)',
                        background: 'linear-gradient(135deg, #1a237e, #42a5f5)',
                      }
                    }} 
                    disabled={loading}
                  >
                    {loading ? "Création..." : "Créer un compte"}
                  </Button>
                </form>
                <Divider sx={{ my: 3 }}>
                  <Typography variant="body2" color="text.secondary">
                    Vous avez déjà un compte ?
                  </Typography>
                </Divider>
                <Button 
                  variant="outlined" 
                  fullWidth 
                  sx={{ 
                    borderRadius: 2,
                    textTransform: 'none',
                    fontWeight: 600,
                    py: 1.5
                  }}
                  onClick={() => setTab(1)}
                >
                  Se connecter
                </Button>
              </Box>
            </Fade>
          )}

          {tab === 1 && (
            <Fade in timeout={500}>
              <Box>
                <form onSubmit={handleLogin}>
                  <TextField 
                    label="Email" 
                    type="email"
                    fullWidth 
                    margin="normal" 
                    value={email} 
                    onChange={e => setEmail(e.target.value)}
                    required
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Email color="primary" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        transition: 'all 0.3s ease',
                        '&:hover fieldset': {
                          borderColor: 'primary.main',
                        },
                        '&.Mui-focused fieldset': {
                          borderWidth: 2,
                          boxShadow: '0 0 0 4px rgba(25, 118, 210, 0.1)'
                        }
                      }
                    }}
                  />
                  <TextField 
                    label="Mot de passe" 
                    type={showPassword ? "text" : "password"}
                    fullWidth 
                    margin="normal" 
                    value={password} 
                    onChange={e => setPassword(e.target.value)}
                    required
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Lock color="primary" />
                        </InputAdornment>
                      ),
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            aria-label="toggle password visibility"
                            onClick={handleClickShowPassword}
                            edge="end"
                            size="small"
                          >
                            {showPassword ? <VisibilityOff /> : <Visibility />}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        transition: 'all 0.3s ease',
                        '&:hover fieldset': {
                          borderColor: 'primary.main',
                        },
                        '&.Mui-focused fieldset': {
                          borderWidth: 2,
                          boxShadow: '0 0 0 4px rgba(25, 118, 210, 0.1)'
                        }
                      }
                    }}
                  />
                  <Button 
                    type="submit" 
                    variant="contained" 
                    color="primary" 
                    fullWidth 
                    sx={{ 
                      mt: 3, 
                      py: 1.5,
                      borderRadius: 2,
                      fontSize: '1rem',
                      fontWeight: 600,
                      textTransform: 'none',
                      background: 'linear-gradient(135deg, #1a237e, #42a5f5)',
                      boxShadow: '0 4px 12px rgba(25, 118, 210, 0.3)',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 6px 16px rgba(25, 118, 210, 0.4)',
                        background: 'linear-gradient(135deg, #1a237e, #42a5f5)',
                      }
                    }} 
                    disabled={loading}
                  >
                    {loading ? "Connexion..." : "Se connecter"}
                  </Button>
                </form>
                <Divider sx={{ my: 3 }}>
                  <Typography variant="body2" color="text.secondary">
                    Pas encore de compte ?
                  </Typography>
                </Divider>
                <Button 
                  variant="outlined" 
                  fullWidth 
                  sx={{ 
                    borderRadius: 2,
                    textTransform: 'none',
                    fontWeight: 600,
                    py: 1.5
                  }}
                  onClick={() => setTab(0)}
                >
                  Créer un compte
                </Button>
              </Box>
            </Fade>
          )}
        </Paper>
      </Fade>
    </Box>
  );
};

export default Auth;