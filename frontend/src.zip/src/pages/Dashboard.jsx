import React from "react";
import Layout from "./LayoutWrapper";
import { Grid, Paper, Typography } from "@mui/material";

const Dashboard = () => {
  return (
    <Layout>
      <Typography variant="h4" gutterBottom>
        📊 Tableau de bord
      </Typography>

      <Grid container spacing={3}>
        {/* Carte 1 */}
        <Grid item xs={12} sm={6} md={3}>
          <Paper
            elevation={3}
            sx={{ p: 2, borderRadius: 3, textAlign: "center" }}
          >
            <Typography variant="h6">Employés</Typography>
            <Typography variant="h4" color="primary">
              120
            </Typography>
          </Paper>
        </Grid>

        {/* Carte 2 */}
        <Grid item xs={12} sm={6} md={3}>
          <Paper
            elevation={3}
            sx={{ p: 2, borderRadius: 3, textAlign: "center" }}
          >
            <Typography variant="h6">Départements</Typography>
            <Typography variant="h4" color="secondary">
              8
            </Typography>
          </Paper>
        </Grid>

        {/* Carte 3 */}
        <Grid item xs={12} sm={6} md={3}>
          <Paper
            elevation={3}
            sx={{ p: 2, borderRadius: 3, textAlign: "center" }}
          >
            <Typography variant="h6">Absences</Typography>
            <Typography variant="h4" color="error">
              5
            </Typography>
          </Paper>
        </Grid>

        {/* Carte 4 */}
        <Grid item xs={12} sm={6} md={3}>
          <Paper
            elevation={3}
            sx={{ p: 2, borderRadius: 3, textAlign: "center" }}
          >
            <Typography variant="h6">Congés</Typography>
            <Typography variant="h4" color="success.main">
              12
            </Typography>
          </Paper>
        </Grid>
      </Grid>
    </Layout>
  );
};

export default Dashboard;
