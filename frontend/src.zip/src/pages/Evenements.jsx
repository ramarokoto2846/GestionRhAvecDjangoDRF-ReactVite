import React, { useState, useEffect } from "react";
import {
  AppBar, Toolbar, Box, Typography, IconButton, Badge, Avatar, Button,
  Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Divider,
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem,
  Chip, Alert, Snackbar, Fab, Card, CardContent, Grid, TablePagination
} from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import { Link, useLocation } from "react-router-dom";
import { format, parseISO } from "date-fns";
import { fr } from "date-fns/locale";

import NotificationsIcon from "@mui/icons-material/Notifications";
import SettingsIcon from "@mui/icons-material/Settings";
import LogoutIcon from "@mui/icons-material/Logout";
import MenuIcon from "@mui/icons-material/Menu";
import HomeIcon from "@mui/icons-material/Home";
import PeopleIcon from "@mui/icons-material/People";
import ApartmentIcon from "@mui/icons-material/Apartment";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import BeachAccessIcon from '@mui/icons-material/BeachAccess';
import BlockIcon from '@mui/icons-material/Block';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';

import * as api from "../services/api";

const drawerWidth = 240;

const Evenements = () => {
  const theme = useTheme();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [evenements, setEvenements] = useState([]);
  const [currentEvenement, setCurrentEvenement] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    id_evenement: "",
    titre: "",
    description: "",
    date_debut: "",
    date_fin: "",
    lieu: ""
  });
  const [errors, setErrors] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const user = { nom: "Admin", email: "admin@example.com" };
  const notificationsCount = 3;

  useEffect(() => {
    fetchEvenements();
  }, []);

  const fetchEvenements = async () => {
    try {
      setLoading(true);
      const data = await api.getEvenements();
      setEvenements(data);
    } catch (error) {
      showSnackbar("Erreur lors du chargement des événements: " + error.message, "error");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("access_token");
    window.location.href = "/";
  };

  const handleOpenDialog = (evenement = null) => {
    if (evenement) {
      setCurrentEvenement(evenement);
      setFormData({
        id_evenement: evenement.id_evenement,
        titre: evenement.titre,
        description: evenement.description || "",
        date_debut: formatDateForInput(evenement.date_debut),
        date_fin: formatDateForInput(evenement.date_fin),
        lieu: evenement.lieu || ""
      });
    } else {
      setCurrentEvenement(null);
      setFormData({
        id_evenement: "",
        titre: "",
        description: "",
        date_debut: "",
        date_fin: "",
        lieu: ""
      });
    }
    setErrors({});
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ""
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = {};
    if (!formData.id_evenement) newErrors.id_evenement = "ID événement requis";
    if (!formData.titre) newErrors.titre = "Titre requis";
    if (!formData.date_debut) newErrors.date_debut = "Date de début requise";
    if (!formData.date_fin) newErrors.date_fin = "Date de fin requise";
    if (formData.date_debut && formData.date_fin && new Date(formData.date_debut) >= new Date(formData.date_fin)) {
      newErrors.date_fin = "La date de fin doit être postérieure à la date de début";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      if (currentEvenement) {
        await api.updateEvenement(currentEvenement.id_evenement, formData);
        showSnackbar("Événement modifié avec succès", "success");
      } else {
        await api.createEvenement(formData);
        showSnackbar("Événement créé avec succès", "success");
      }
      fetchEvenements();
      handleCloseDialog();
    } catch (error) {
      showSnackbar("Erreur: " + error.message, "error");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer cet événement ?")) {
      try {
        await api.deleteEvenement(id);
        showSnackbar("Événement supprimé avec succès", "success");
        fetchEvenements();
      } catch (error) {
        showSnackbar("Erreur lors de la suppression: " + error.message, "error");
      }
    }
  };

  const showSnackbar = (message, severity = "success") => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const formatDateForInput = (dateString) => {
    if (!dateString) return "";
    const date = parseISO(dateString);
    return format(date, "yyyy-MM-dd'T'HH:mm");
  };

  const formatDateForDisplay = (dateString) => {
    if (!dateString) return "";
    const date = parseISO(dateString);
    return format(date, "dd/MM/yyyy HH:mm", { locale: fr });
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const filteredEvenements = evenements.filter(
    (evenement) =>
      evenement.titre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (evenement.lieu && evenement.lieu.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const menuItems = [
    { text: "Accueil", path: "/Home", icon: <HomeIcon /> },
    { text: "Employés", path: "/employes", icon: <PeopleIcon /> },
    { text: "Départements", path: "/departements", icon: <ApartmentIcon /> },
    { text: "Pointages", path: "/pointages", icon: <AccessTimeIcon /> },
    { text: "Congés", path: "/conges", icon: <BeachAccessIcon /> },
    { text: "Absences", path: "/absences", icon: <BlockIcon /> },
    { text: "Événements", path: "/evenements", icon: <EventAvailableIcon /> }
  ];

  return (
    <Box sx={{ display: "flex" }}>
      {/* AppBar */}
      <AppBar position="fixed" elevation={0} sx={{ bgcolor: "white", color: "text.primary", borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`, zIndex: theme.zIndex.drawer + 1 }}>
        <Toolbar>
          <IconButton color="inherit" onClick={() => setOpen(!open)} sx={{ mr: 2, display: { md: "none" } }}><MenuIcon /></IconButton>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: "primary.main", display: "flex", alignItems: "center", justifyContent: "center", mr: 2, color: "white", fontWeight: "bold", fontSize: 18 }}>RH</Box>
            <Typography variant="h6" sx={{ fontWeight: "bold", color: "#1976d2" }}>RHManager Pro</Typography>
          </Box>
          <Box sx={{ flexGrow: 1 }} />
          <IconButton color="inherit" sx={{ mr: 1, bgcolor: alpha(theme.palette.primary.main, 0.1), "&:hover": { bgcolor: alpha(theme.palette.primary.main, 0.2) } }}>
            <Badge badgeContent={notificationsCount} color="error"><NotificationsIcon /></Badge>
          </IconButton>
          <IconButton sx={{ mr: 1, bgcolor: alpha(theme.palette.grey[500], 0.1), "&:hover": { bgcolor: alpha(theme.palette.grey[500], 0.2) } }}><SettingsIcon /></IconButton>
          <Box sx={{ display: "flex", alignItems: "center", mr: 2 }}>
            <Avatar sx={{ bgcolor: "primary.main", width: 40, height: 40, mr: 1.5, fontSize: 16, fontWeight: "bold" }}>{user.nom.charAt(0).toUpperCase()}</Avatar>
            <Box sx={{ display: { xs: "none", sm: "block" } }}>
              <Typography variant="body2" sx={{ fontWeight: "medium" }}>{user.nom}</Typography>
              <Typography variant="caption" color="text.secondary">Administrateur</Typography>
            </Box>
          </Box>
          <Button color="error" onClick={handleLogout} startIcon={<LogoutIcon />} variant="outlined" size="small" sx={{ borderRadius: 2, textTransform: "none", fontWeight: "medium" }}>Déconnexion</Button>
        </Toolbar>
      </AppBar>

      {/* Sidebar */}
      <Drawer variant="permanent" sx={{ width: drawerWidth, flexShrink: 0, [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: "border-box" }, display: { xs: "none", md: "block" } }} open>
        <Toolbar /><Divider />
        <List>
          {menuItems.map(item => (
            <ListItem key={item.text} disablePadding>
              <ListItemButton component={Link} to={item.path} selected={location.pathname === item.path}>
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>

      {/* Sidebar mobile */}
      <Drawer anchor="left" open={open} onClose={() => setOpen(false)} sx={{ display: { md: "none" } }}>
        <Box sx={{ width: drawerWidth }} role="presentation">
          <List>
            {menuItems.map(item => (
              <ListItem key={item.text} disablePadding>
                <ListItemButton component={Link} to={item.path} onClick={() => setOpen(false)} selected={location.pathname === item.path}>
                  <ListItemIcon>{item.icon}</ListItemIcon>
                  <ListItemText primary={item.text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Contenu */}
      <Box component="main" sx={{ flexGrow: 1, bgcolor: "#f5f5f5", minHeight: "100vh", p: 3, mt: 8, ml: { md: `${drawerWidth}px` } }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
          <Typography variant="h4" gutterBottom>🎉 Gestion des Événements</Typography>
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <TextField
              label="Rechercher un événement"
              variant="outlined"
              size="small"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              sx={{ width: 300 }}
            />
            <Fab color="primary" aria-label="add" onClick={() => handleOpenDialog()}>
              <AddIcon />
            </Fab>
          </Box>
        </Box>

        {loading ? (
          <Typography>Chargement des événements...</Typography>
        ) : filteredEvenements.length === 0 ? (
          <Card>
            <CardContent sx={{ textAlign: "center", py: 4 }}>
              <CalendarTodayIcon sx={{ fontSize: 60, color: "text.secondary", mb: 2 }} />
              <Typography variant="h6" color="text.secondary">
                Aucun événement planifié
              </Typography>
              <Button 
                variant="contained" 
                sx={{ mt: 2 }}
                onClick={() => handleOpenDialog()}
              >
                Créer le premier événement
              </Button>
            </CardContent>
          </Card>
        ) : (
          <TableContainer component={Paper} elevation={2}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: "primary.light" }}>
                  <TableCell sx={{ color: "white", fontWeight: "bold" }}>ID</TableCell>
                  <TableCell sx={{ color: "white", fontWeight: "bold" }}>Titre</TableCell>
                  <TableCell sx={{ color: "white", fontWeight: "bold" }}>Description</TableCell>
                  <TableCell sx={{ color: "white", fontWeight: "bold" }}>Début</TableCell>
                  <TableCell sx={{ color: "white", fontWeight: "bold" }}>Fin</TableCell>
                  <TableCell sx={{ color: "white", fontWeight: "bold" }}>Lieu</TableCell>
                  <TableCell sx={{ color: "white", fontWeight: "bold" }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredEvenements
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((evenement) => (
                    <TableRow key={evenement.id_evenement} hover>
                      <TableCell>{evenement.id_evenement}</TableCell>
                      <TableCell sx={{ fontWeight: "medium" }}>{evenement.titre}</TableCell>
                      <TableCell>{evenement.description || "Aucune description"}</TableCell>
                      <TableCell>{formatDateForDisplay(evenement.date_debut)}</TableCell>
                      <TableCell>{formatDateForDisplay(evenement.date_fin)}</TableCell>
                      <TableCell>{evenement.lieu || "Non spécifié"}</TableCell>
                      <TableCell>
                        <IconButton 
                          color="primary" 
                          onClick={() => handleOpenDialog(evenement)}
                          size="small"
                          sx={{ mr: 1 }}
                        >
                          <EditIcon />
                        </IconButton>
                        <IconButton 
                          color="error" 
                          onClick={() => handleDelete(evenement.id_evenement)}
                          size="small"
                        >
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={filteredEvenements.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              labelRowsPerPage="Événements par page :"
              labelDisplayedRows={({ from, to, count }) => `${from}–${to} sur ${count}`}
            />
          </TableContainer>
        )}

        {/* Dialog pour ajouter/modifier un événement */}
        <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
          <DialogTitle>
            {currentEvenement ? "Modifier l'événement" : "Créer un nouvel événement"}
          </DialogTitle>
          <form onSubmit={handleSubmit}>
            <DialogContent>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="ID Événement *"
                    name="id_evenement"
                    value={formData.id_evenement}
                    onChange={handleInputChange}
                    error={!!errors.id_evenement}
                    helperText={errors.id_evenement}
                    disabled={!!currentEvenement}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Titre *"
                    name="titre"
                    value={formData.titre}
                    onChange={handleInputChange}
                    error={!!errors.titre}
                    helperText={errors.titre}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    multiline
                    rows={3}
                    label="Description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Date et heure de début *"
                    name="date_debut"
                    type="datetime-local"
                    value={formData.date_debut}
                    onChange={handleInputChange}
                    error={!!errors.date_debut}
                    helperText={errors.date_debut}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Date et heure de fin *"
                    name="date_fin"
                    type="datetime-local"
                    value={formData.date_fin}
                    onChange={handleInputChange}
                    error={!!errors.date_fin}
                    helperText={errors.date_fin}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Lieu"
                    name="lieu"
                    value={formData.lieu}
                    onChange={handleInputChange}
                  />
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDialog}>Annuler</Button>
              <Button type="submit" variant="contained">
                {currentEvenement ? "Modifier" : "Créer"}
              </Button>
            </DialogActions>
          </form>
        </Dialog>

        {/* Snackbar pour les notifications */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={handleCloseSnackbar}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: "100%" }}>
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </Box>
  );
};

export default Evenements;