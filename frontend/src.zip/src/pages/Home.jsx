import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Button,
  Typography,
  Grid,
  Card,
  CardContent,
  AppBar,
  Toolbar,
  Avatar,
  IconButton,
  useTheme,
  useMediaQuery,
  alpha,
  Badge,
  Chip,
  Container
} from "@mui/material";
import {
  ExitToApp as LogoutIcon,
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  Event as EventIcon,
  AccessTime as TimeIcon,
  Notifications as NotificationsIcon,
  TrendingUp as StatsIcon,
  Settings as SettingsIcon,
  ChevronRight as ChevronRightIcon
} from "@mui/icons-material";
import axios from "axios";

const Home = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const [user, setUser] = useState(null);
  const [notificationsCount, setNotificationsCount] = useState(3); // Exemple de compteur de notifications

  // Logout sûr
  const handleLogout = () => {
    console.log("Déconnexion...");
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    // Forcer le reload pour s'assurer que tous les states sont réinitialisés
    window.location.href = "/";
  };

  // Récupération des infos utilisateur
  useEffect(() => {
    const fetchUser = async () => {
      const token = localStorage.getItem("access_token");
      if (!token) return navigate("/");

      try {
        const res = await axios.get("http://localhost:8000/api/users/me/", {
          headers: { Authorization: `Bearer ${token}` }
        });
        setUser(res.data);
      } catch (err) {
        console.error(err);
        // Redirection si token invalide ou expiré
        window.location.href = "/";
      }
    };
    fetchUser();
  }, [navigate]);

  // Actions rapides
  const quickActions = [
    { icon: <PeopleIcon />, label: "Départements", path: "/departements", color: "#FF6B6B" },
    { icon: <PeopleIcon />, label: "Employés", path: "/employes", color: "#4ECDC4" },
    { icon: <TimeIcon />, label: "Pointages", path: "/pointages", color: "#45B7D1" },
    { icon: <EventIcon />, label: "Congés", path: "/conges", color: "#F9A826" },
    { icon: <EventIcon />, label: "Absences", path: "/absences", color: "#7467EF" },
    { icon: <EventIcon />, label: "Événements", path: "/evenements", color: "#FF9E43" }
  ];

  // Statistiques (exemple)
  const stats = [
    { label: "Employés actifs", value: "142", change: "+5% ce mois" },
    { label: "Congés en attente", value: "23", change: "3 nouveaux" },
    { label: "Pointages aujourd'hui", value: "89", change: "87% de présence" },
  ];

  return (
    <Box sx={{ flexGrow: 1, minHeight: '100vh', bgcolor: '#f8fafc' }}>
      {/* Header */}
      <AppBar 
        position="static" 
        elevation={0} 
        sx={{ 
          bgcolor: 'white', 
          color: 'text.primary',
          borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
          py: 0.5
        }}
      >
        <Toolbar>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Box 
              sx={{ 
                width: 40, 
                height: 40, 
                borderRadius: 2,
                bgcolor: 'primary.main',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mr: 2,
                color: 'white',
                fontWeight: 'bold',
                fontSize: 18
              }}
            >
              RH
            </Box>
            <Typography variant="h6" component="div" sx={{ fontWeight: 'bold', color: '#1976d2' }}>
              RHManager Pro
            </Typography>
          </Box>
          
          <Box sx={{ flexGrow: 1 }} />
          
          <IconButton 
            color="inherit" 
            sx={{ 
              mr: 1,
              bgcolor: alpha(theme.palette.primary.main, 0.1),
              '&:hover': { bgcolor: alpha(theme.palette.primary.main, 0.2) }
            }}
          >
            <Badge badgeContent={notificationsCount} color="error">
              <NotificationsIcon />
            </Badge>
          </IconButton>
          
          <IconButton 
            sx={{ 
              mr: 1,
              bgcolor: alpha(theme.palette.grey[500], 0.1),
              '&:hover': { bgcolor: alpha(theme.palette.grey[500], 0.2) }
            }}
          >
            <SettingsIcon />
          </IconButton>
          
          <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
            <Avatar 
              sx={{ 
                bgcolor: 'primary.main', 
                width: 40, 
                height: 40, 
                mr: 1.5,
                fontSize: 16,
                fontWeight: 'bold'
              }}
            >
              {user ? user.nom?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase() : 'U'}
            </Avatar>
            
            <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
              <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                {user ? user.nom || user.email : 'Chargement...'}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Administrateur
              </Typography>
            </Box>
          </Box>

          <Button 
            color="error" 
            onClick={handleLogout} 
            startIcon={<LogoutIcon />}
            variant="outlined"
            size="small"
            sx={{ 
              borderRadius: 2,
              textTransform: 'none',
              fontWeight: 'medium'
            }}
          >
            Déconnexion
          </Button>
        </Toolbar>
      </AppBar>

      {/* Main Content */}
      <Container maxWidth="xl" sx={{ py: isMobile ? 2 : 4, px: isMobile ? 2 : 3 }}>
        {/* Welcome Section */}
        <Box 
          sx={{ 
            bgcolor: 'white',
            borderRadius: 4,
            mb: 4,
            p: 4,
            position: 'relative',
            overflow: 'hidden',
            boxShadow: '0 10px 40px rgba(0,0,0,0.05)',
            background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.1)} 0%, ${alpha(theme.palette.primary.light, 0.2)} 100%)`,
            border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
          }}
        >
          <Box sx={{ position: 'relative', zIndex: 2 }}>
            <Chip 
              label="Espace administrateur" 
              size="small" 
              sx={{ 
                mb: 2, 
                bgcolor: alpha(theme.palette.primary.main, 0.1),
                color: 'primary.dark',
                fontWeight: 'medium'
              }} 
            />
            
            <Typography variant="h3" component="h1" gutterBottom sx={{ fontWeight: 'bold', color: 'text.primary' }}>
              Bienvenue, {user ? user.nom || user.email : 'Administrateur'}
            </Typography>
            
            <Typography variant="h6" sx={{ color: 'text.secondary', mb: 4, maxWidth: 600 }}>
              Gérez efficacement vos ressources humaines et optimisez la productivité de votre entreprise
            </Typography>
            
            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <Button 
                variant="contained" 
                size="large"
                sx={{ 
                  borderRadius: 3,
                  px: 4,
                  py: 1,
                  textTransform: 'none',
                  fontWeight: 'bold',
                  boxShadow: '0 8px 20px rgba(25, 118, 210, 0.3)'
                }}
                onClick={() => navigate("/stats")}
                endIcon={<StatsIcon />}
              >
                Tableau de bord
              </Button>
              
              <Button 
                variant="outlined" 
                size="large"
                sx={{ 
                  borderRadius: 3,
                  px: 4,
                  py: 1,
                  textTransform: 'none',
                  fontWeight: 'medium'
                }}
                onClick={() => navigate("/employes")}
              >
                Voir les employés
              </Button>
            </Box>
          </Box>
          
          {/* Éléments décoratifs */}
          <Box 
            sx={{ 
              position: 'absolute', 
              top: -20, 
              right: -20, 
              width: 200, 
              height: 200, 
              borderRadius: '50%', 
              bgcolor: alpha(theme.palette.primary.main, 0.1),
              zIndex: 1
            }} 
          />
          <Box 
            sx={{ 
              position: 'absolute', 
              bottom: -30, 
              right: 100, 
              width: 150, 
              height: 150, 
              borderRadius: '50%', 
              bgcolor: alpha(theme.palette.secondary.main, 0.1),
              zIndex: 1
            }} 
          />
        </Box>

        {/* Stats Overview */}
        <Grid container spacing={3} sx={{ mb: 5 }}>
          {stats.map((stat, index) => (
            <Grid item xs={12} md={4} key={index}>
              <Card 
                sx={{ 
                  borderRadius: 3,
                  boxShadow: '0 5px 20px rgba(0,0,0,0.05)',
                  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                  }
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Typography variant="h4" component="div" sx={{ fontWeight: 'bold', mb: 1 }}>
                    {stat.value}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {stat.label}
                  </Typography>
                  <Chip 
                    label={stat.change} 
                    size="small" 
                    sx={{ 
                      bgcolor: alpha(theme.palette.primary.main, 0.1),
                      color: 'primary.dark',
                      fontWeight: 'medium',
                      fontSize: '0.7rem'
                    }} 
                  />
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Quick Actions */}
        <Typography variant="h5" gutterBottom sx={{ mb: 3, fontWeight: 'bold', color: 'text.primary' }}>
          Accès rapide
        </Typography>
        
        <Grid container spacing={3} sx={{ mb: 6 }}>
          {quickActions.map((action, index) => (
            <Grid item xs={12} sm={6} md={4} lg={2} key={index}>
              <Card 
                sx={{ 
                  height: '100%', 
                  cursor: 'pointer', 
                  transition: 'transform 0.2s, box-shadow 0.2s',
                  borderRadius: 3,
                  boxShadow: '0 5px 15px rgba(0,0,0,0.05)',
                  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                  '&:hover': {
                    transform: 'translateY(-8px)',
                    boxShadow: '0 12px 30px rgba(0,0,0,0.1)'
                  }
                }}
                onClick={() => navigate(action.path)}
              >
                <CardContent sx={{ textAlign: 'center', p: 3 }}>
                  <Box 
                    sx={{ 
                      width: 60, 
                      height: 60, 
                      borderRadius: 3,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mx: 'auto',
                      mb: 2,
                      bgcolor: alpha(action.color, 0.2),
                      color: action.color
                    }}
                  >
                    {React.cloneElement(action.icon, { sx: { fontSize: 30 } })}
                  </Box>
                  
                  <Typography variant="h6" sx={{ fontWeight: 'medium', mb: 1 }}>
                    {action.label}
                  </Typography>
                  
                  <Box 
                    sx={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center', 
                      color: 'primary.main',
                      mt: 1
                    }}
                  >
                    <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                      Accéder
                    </Typography>
                    <ChevronRightIcon sx={{ fontSize: 18 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Footer */}
      <Box sx={{ 
        bgcolor: 'white', 
        py: 4, 
        mt: 6, 
        textAlign: 'center',
        borderTop: `1px solid ${alpha(theme.palette.divider, 0.1)}`
      }}>
        <Container maxWidth="xl">
          <Typography variant="body2" color="text.secondary">
            © 2024 RHManager Pro - Tous droits réservés
          </Typography>
        </Container>
      </Box>
    </Box>
  );
};

export default Home;