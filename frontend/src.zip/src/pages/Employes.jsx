import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  IconButton,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Chip,
  Alert,
  Snackbar,
  Fab,
  Card,
  Grid,
  Avatar,
  InputAdornment,
  Tooltip,
  alpha,
  useTheme
} from "@mui/material";
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Visibility as ViewIcon,
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  Work as WorkIcon,
  Business as BusinessIcon
} from "@mui/icons-material";
import { getEmployes, createEmploye, updateEmploye, deleteEmploye, getDepartements } from "../services/api";
import Swal from "sweetalert2";

const Employes = () => {
  const theme = useTheme();
  const [employes, setEmployes] = useState([]);
  const [departements, setDepartements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingEmploye, setEditingEmploye] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });
  const [formData, setFormData] = useState({
    matricule: "",
    titre: "stagiaire",
    nom: "",
    prenom: "",
    email: "",
    telephone: "",
    poste: "",
    departement_pk: "",
    statut: "actif"
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [employesData, departementsData] = await Promise.all([
        getEmployes(),
        getDepartements()
      ]);
      setEmployes(employesData);
      setDepartements(departementsData);
    } catch (error) {
      showSnackbar("Erreur lors du chargement des données", "error");
    } finally {
      setLoading(false);
    }
  };

  const showSnackbar = (message, severity = "success") => {
    setSnackbar({ open: true, message, severity });
  };

  const handleOpenDialog = (employe = null) => {
    if (employe) {
      setEditingEmploye(employe);
      setFormData({
        matricule: employe.matricule,
        titre: employe.titre,
        nom: employe.nom,
        prenom: employe.prenom,
        email: employe.email,
        telephone: employe.telephone || "",
        poste: employe.poste,
        departement_pk: employe.departement?.id_departement || "",
        statut: employe.statut
      });
    } else {
      setEditingEmploye(null);
      setFormData({
        matricule: "",
        titre: "stagiaire",
        nom: "",
        prenom: "",
        email: "",
        telephone: "",
        poste: "",
        departement_pk: "",
        statut: "actif"
      });
    }
    setErrors({});
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingEmploye(null);
    setErrors({});
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      
      if (editingEmploye) {
        await updateEmploye(editingEmploye.matricule, formData);
        showSnackbar("Employé modifié avec succès");
      } else {
        await createEmploye(formData);
        showSnackbar("Employé créé avec succès");
      }
      
      handleCloseDialog();
      fetchData();
    } catch (error) {
      if (error.response?.data) {
        setErrors(error.response.data);
      } else {
        showSnackbar("Erreur lors de l'opération", "error");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (matricule) => {
    const result = await Swal.fire({
      title: 'Êtes-vous sûr?',
      text: "Vous ne pourrez pas annuler cette action!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Oui, supprimer!',
      cancelButtonText: 'Annuler',
      background: theme.palette.background.paper,
      color: theme.palette.text.primary
    });

    if (result.isConfirmed) {
      try {
        await deleteEmploye(matricule);
        showSnackbar("Employé supprimé avec succès");
        fetchData();
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const filteredEmployes = employes.filter(employe =>
    employe.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employe.prenom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employe.matricule.includes(searchTerm) ||
    employe.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employe.poste.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const paginatedEmployes = filteredEmployes.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  const getStatusColor = (statut) => {
    return statut === 'actif' ? 'success' : 'error';
  };

  const getTitreColor = (titre) => {
    return titre === 'employe' ? 'primary' : 'secondary';
  };

  if (loading && employes.length === 0) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '400px' }}>
        <Typography>Chargement...</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Card 
        sx={{ 
          mb: 3, 
          p: 3, 
          background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
          color: 'white',
          borderRadius: 3
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Box>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold' }}>
              Gestion des Employés
            </Typography>
            <Typography variant="body1">
              {employes.length} employé(s) au total
            </Typography>
          </Box>
          <Fab
            color="secondary"
            aria-label="add"
            onClick={() => handleOpenDialog()}
            sx={{
              boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
              '&:hover': {
                transform: 'translateY(-2px)',
                boxShadow: '0 12px 35px rgba(0,0,0,0.2)'
              }
            }}
          >
            <AddIcon />
          </Fab>
        </Box>
      </Card>

      {/* Search and Stats */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={8}>
          <TextField
            fullWidth
            placeholder="Rechercher un employé..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon color="primary" />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 3,
                backgroundColor: alpha(theme.palette.primary.main, 0.05),
                '&:hover': {
                  backgroundColor: alpha(theme.palette.primary.main, 0.1)
                }
              }
            }}
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ p: 2, textAlign: 'center', borderRadius: 3 }}>
            <Typography variant="h6" color="primary">
              {employes.filter(e => e.statut === 'actif').length}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Employés actifs
            </Typography>
          </Card>
        </Grid>
      </Grid>

      {/* Table */}
      <Paper sx={{ width: '100%', overflow: 'hidden', borderRadius: 3 }}>
        <TableContainer sx={{ maxHeight: 600 }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 'bold', backgroundColor: theme.palette.background.default }}>
                  Employé
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', backgroundColor: theme.palette.background.default }}>
                  Contact
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', backgroundColor: theme.palette.background.default }}>
                  Poste
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', backgroundColor: theme.palette.background.default }}>
                  Département
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', backgroundColor: theme.palette.background.default }}>
                  Statut
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', backgroundColor: theme.palette.background.default }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedEmployes.map((employe) => (
                <TableRow
                  key={employe.matricule}
                  hover
                  sx={{
                    '&:hover': {
                      backgroundColor: alpha(theme.palette.primary.main, 0.04)
                    }
                  }}
                >
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      <Avatar
                        sx={{
                          bgcolor: alpha(theme.palette.primary.main, 0.2),
                          color: theme.palette.primary.main
                        }}
                      >
                        <PersonIcon />
                      </Avatar>
                      <Box>
                        <Typography variant="subtitle2" fontWeight="bold">
                          {employe.prenom} {employe.nom}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {employe.matricule}
                        </Typography>
                        <Chip
                          label={employe.titre}
                          size="small"
                          color={getTitreColor(employe.titre)}
                          variant="outlined"
                        />
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        <EmailIcon fontSize="small" color="primary" />
                        <Typography variant="body2">
                          {employe.email}
                        </Typography>
                      </Box>
                      {employe.telephone && (
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <PhoneIcon fontSize="small" color="primary" />
                          <Typography variant="body2">
                            {employe.telephone}
                          </Typography>
                        </Box>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <WorkIcon fontSize="small" color="primary" />
                      <Typography variant="body2">
                        {employe.poste}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    {employe.departement && (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <BusinessIcon fontSize="small" color="primary" />
                        <Typography variant="body2">
                          {employe.departement.nom}
                        </Typography>
                      </Box>
                    )}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={employe.statut}
                      color={getStatusColor(employe.statut)}
                      variant="filled"
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Tooltip title="Modifier">
                        <IconButton
                          color="primary"
                          onClick={() => handleOpenDialog(employe)}
                          size="small"
                        >
                          <EditIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Supprimer">
                        <IconButton
                          color="error"
                          onClick={() => handleDelete(employe.matricule)}
                          size="small"
                        >
                          <DeleteIcon />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={filteredEmployes.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={(e, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
        />
      </Paper>

      {/* Add/Edit Dialog */}
      <Dialog 
        open={openDialog} 
        onClose={handleCloseDialog}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3
          }
        }}
      >
        <DialogTitle sx={{ 
          backgroundColor: theme.palette.primary.main,
          color: 'white',
          fontWeight: 'bold'
        }}>
          {editingEmploye ? 'Modifier l\'employé' : 'Nouvel employé'}
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Matricule"
                name="matricule"
                value={formData.matricule}
                onChange={handleChange}
                error={!!errors.matricule}
                helperText={errors.matricule}
                disabled={!!editingEmploye}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Titre"
                name="titre"
                value={formData.titre}
                onChange={handleChange}
                select
                required
              >
                <MenuItem value="stagiaire">Stagiaire</MenuItem>
                <MenuItem value="employe">Employé Fixe</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Nom"
                name="nom"
                value={formData.nom}
                onChange={handleChange}
                error={!!errors.nom}
                helperText={errors.nom}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Prénom"
                name="prenom"
                value={formData.prenom}
                onChange={handleChange}
                error={!!errors.prenom}
                helperText={errors.prenom}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                error={!!errors.email}
                helperText={errors.email}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Téléphone"
                name="telephone"
                value={formData.telephone}
                onChange={handleChange}
                error={!!errors.telephone}
                helperText={errors.telephone}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Poste"
                name="poste"
                value={formData.poste}
                onChange={handleChange}
                error={!!errors.poste}
                helperText={errors.poste}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Département"
                name="departement_pk"
                value={formData.departement_pk}
                onChange={handleChange}
                select
                required
                error={!!errors.departement_pk}
                helperText={errors.departement_pk}
              >
                {departements.map((dept) => (
                  <MenuItem key={dept.id_departement} value={dept.id_departement}>
                    {dept.nom}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Statut"
                name="statut"
                value={formData.statut}
                onChange={handleChange}
                select
                required
              >
                <MenuItem value="actif">Actif</MenuItem>
                <MenuItem value="inactif">Inactif</MenuItem>
              </TextField>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3, gap: 1 }}>
          <Button onClick={handleCloseDialog} color="inherit">
            Annuler
          </Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            disabled={loading}
            sx={{
              borderRadius: 2,
              px: 3,
              py: 1
            }}
          >
            {loading ? 'En cours...' : (editingEmploye ? 'Modifier' : 'Créer')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert 
          severity={snackbar.severity} 
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          sx={{ borderRadius: 2 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Employes;