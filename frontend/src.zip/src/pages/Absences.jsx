import React, { useState } from "react";
import {
  AppBar, Toolbar, Box, Typography, IconButton, Badge, Avatar, Button,
  Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Divider
} from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import { Link, useLocation } from "react-router-dom";

import NotificationsIcon from "@mui/icons-material/Notifications";
import SettingsIcon from "@mui/icons-material/Settings";
import LogoutIcon from "@mui/icons-material/Logout";
import MenuIcon from "@mui/icons-material/Menu";
import HomeIcon from "@mui/icons-material/Home";
import PeopleIcon from "@mui/icons-material/People";
import ApartmentIcon from "@mui/icons-material/Apartment";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import BeachAccessIcon from '@mui/icons-material/BeachAccess';
import BlockIcon from '@mui/icons-material/Block';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';

const drawerWidth = 240;

const Absences = () => {
  const theme = useTheme();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const user = { nom: "Admin", email: "admin@example.com" };
  const notificationsCount = 3;

  const handleLogout = () => {
    localStorage.removeItem("access_token");
    window.location.href = "/";
  };

  const menuItems = [
    { text: "Accueil", path: "/Home", icon: <HomeIcon /> },
    { text: "Employés", path: "/employes", icon: <PeopleIcon /> },
    { text: "Départements", path: "/departements", icon: <ApartmentIcon /> },
    { text: "Pointages", path: "/pointages", icon: <AccessTimeIcon /> },
    { text: "Congés", path: "/conges", icon: <BeachAccessIcon /> },
    { text: "Absences", path: "/absences", icon: <BlockIcon /> },
    { text: "Événements", path: "/evenements", icon: <EventAvailableIcon /> }
  ];

  return (
    <Box sx={{ display: "flex" }}>
      {/* AppBar */}
      <AppBar position="fixed" elevation={0} sx={{ bgcolor: "white", color: "text.primary", borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`, zIndex: theme.zIndex.drawer + 1 }}>
        <Toolbar>
          <IconButton color="inherit" onClick={() => setOpen(!open)} sx={{ mr: 2, display: { md: "none" } }}><MenuIcon /></IconButton>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: "primary.main", display: "flex", alignItems: "center", justifyContent: "center", mr: 2, color: "white", fontWeight: "bold", fontSize: 18 }}>RH</Box>
            <Typography variant="h6" sx={{ fontWeight: "bold", color: "#1976d2" }}>RHManager Pro</Typography>
          </Box>
          <Box sx={{ flexGrow: 1 }} />
          <IconButton color="inherit" sx={{ mr: 1, bgcolor: alpha(theme.palette.primary.main, 0.1), "&:hover": { bgcolor: alpha(theme.palette.primary.main, 0.2) } }}>
            <Badge badgeContent={notificationsCount} color="error"><NotificationsIcon /></Badge>
          </IconButton>
          <IconButton sx={{ mr: 1, bgcolor: alpha(theme.palette.grey[500], 0.1), "&:hover": { bgcolor: alpha(theme.palette.grey[500], 0.2) } }}><SettingsIcon /></IconButton>
          <Box sx={{ display: "flex", alignItems: "center", mr: 2 }}>
            <Avatar sx={{ bgcolor: "primary.main", width: 40, height: 40, mr: 1.5, fontSize: 16, fontWeight: "bold" }}>{user.nom.charAt(0).toUpperCase()}</Avatar>
            <Box sx={{ display: { xs: "none", sm: "block" } }}>
              <Typography variant="body2" sx={{ fontWeight: "medium" }}>{user.nom}</Typography>
              <Typography variant="caption" color="text.secondary">Administrateur</Typography>
            </Box>
          </Box>
          <Button color="error" onClick={handleLogout} startIcon={<LogoutIcon />} variant="outlined" size="small" sx={{ borderRadius: 2, textTransform: "none", fontWeight: "medium" }}>Déconnexion</Button>
        </Toolbar>
      </AppBar>

      {/* Sidebar */}
      <Drawer variant="permanent" sx={{ width: drawerWidth, flexShrink: 0, [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: "border-box" }, display: { xs: "none", md: "block" } }} open>
        <Toolbar /><Divider />
        <List>
          {menuItems.map(item => (
            <ListItem key={item.text} disablePadding>
              <ListItemButton component={Link} to={item.path} selected={location.pathname === item.path}>
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>

      {/* Sidebar mobile */}
      <Drawer anchor="left" open={open} onClose={() => setOpen(false)} sx={{ display: { md: "none" } }}>
        <Box sx={{ width: drawerWidth }} role="presentation">
          <List>
            {menuItems.map(item => (
              <ListItem key={item.text} disablePadding>
                <ListItemButton component={Link} to={item.path} onClick={() => setOpen(false)} selected={location.pathname === item.path}>
                  <ListItemIcon>{item.icon}</ListItemIcon>
                  <ListItemText primary={item.text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Contenu */}
      <Box component="main" sx={{ flexGrow: 1, bgcolor: "#f5f5f5", minHeight: "100vh", p: 3, mt: 8, ml: { md: `${drawerWidth}px` } }}>
        <Typography variant="h4" gutterBottom>🎉 Page Pointages</Typography>
        <Typography>Ici, tu peux gérer les pointages des employés.</Typography>
      </Box>
    </Box>
  );
};

export default Absences;
